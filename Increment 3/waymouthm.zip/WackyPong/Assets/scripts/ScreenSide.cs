﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration for the sides of the screen
/// </summary>
public enum ScreenSide
{
    Left,
    Right
}
