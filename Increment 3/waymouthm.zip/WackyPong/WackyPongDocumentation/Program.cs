﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WackyPongDocumentation
{
    /// <summary>
    /// Dummy class to avoid recurring compiler problems
    /// </summary>
    class Program
    {
        /// <summary>
        /// Dummy method to avoid recurring compiler issues
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
        }
    }
}
